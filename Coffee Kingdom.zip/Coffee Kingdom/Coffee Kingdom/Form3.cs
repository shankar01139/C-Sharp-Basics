﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Coffee_Kingdom
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void coffeeBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.coffeeBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.coffeeDataSet);

        }

        private void Form3_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'coffeeDataSet.coffee' table. You can move, or remove it, as needed.
            this.coffeeTableAdapter.Fill(this.coffeeDataSet.coffee);

        }

        private void countTextBox_TextChanged(object sender, EventArgs e)
        {
            total_PriceTextBox.Text = "65";
            if((checkBox1.Checked) || (checkBox2.Checked))
            {
                total_PriceTextBox.Text = "75";
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
           string Message = "Order Placed...! Wait for Your Turn....";
            MessageBox.Show(Message);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form2 frm2 = new Form2();
            frm2.Show();
            this.Hide();
        }
    }
}
