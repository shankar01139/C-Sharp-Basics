﻿namespace TextBox_Label
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.heading = new System.Windows.Forms.Label();
            this.label_count = new System.Windows.Forms.Label();
            this.textbox_count = new System.Windows.Forms.Label();
            this.label_value = new System.Windows.Forms.NumericUpDown();
            this.textbox_value = new System.Windows.Forms.NumericUpDown();
            this.create = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.label_value)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textbox_value)).BeginInit();
            this.SuspendLayout();
            // 
            // heading
            // 
            this.heading.AutoSize = true;
            this.heading.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.heading.Location = new System.Drawing.Point(12, 97);
            this.heading.Name = "heading";
            this.heading.Size = new System.Drawing.Size(461, 20);
            this.heading.TabIndex = 0;
            this.heading.Text = "How many Textboxes and Labels do you want to Create?";
            // 
            // label_count
            // 
            this.label_count.AutoSize = true;
            this.label_count.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_count.Location = new System.Drawing.Point(209, 157);
            this.label_count.Name = "label_count";
            this.label_count.Size = new System.Drawing.Size(73, 18);
            this.label_count.TabIndex = 1;
            this.label_count.Text = "Label  :  ";
            // 
            // textbox_count
            // 
            this.textbox_count.AutoSize = true;
            this.textbox_count.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textbox_count.Location = new System.Drawing.Point(186, 224);
            this.textbox_count.Name = "textbox_count";
            this.textbox_count.Size = new System.Drawing.Size(84, 18);
            this.textbox_count.TabIndex = 2;
            this.textbox_count.Text = "TextBox  :";
            // 
            // label_value
            // 
            this.label_value.Location = new System.Drawing.Point(288, 155);
            this.label_value.Name = "label_value";
            this.label_value.Size = new System.Drawing.Size(120, 20);
            this.label_value.TabIndex = 3;
            // 
            // textbox_value
            // 
            this.textbox_value.Location = new System.Drawing.Point(287, 222);
            this.textbox_value.Name = "textbox_value";
            this.textbox_value.Size = new System.Drawing.Size(120, 20);
            this.textbox_value.TabIndex = 4;
            // 
            // create
            // 
            this.create.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.create.Location = new System.Drawing.Point(311, 293);
            this.create.Name = "create";
            this.create.Size = new System.Drawing.Size(75, 23);
            this.create.TabIndex = 5;
            this.create.Text = "Create";
            this.create.UseVisualStyleBackColor = true;
            this.create.Click += new System.EventHandler(this.create_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.create);
            this.Controls.Add(this.textbox_value);
            this.Controls.Add(this.label_value);
            this.Controls.Add(this.textbox_count);
            this.Controls.Add(this.label_count);
            this.Controls.Add(this.heading);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.label_value)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textbox_value)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label heading;
        private System.Windows.Forms.Label label_count;
        private System.Windows.Forms.Label textbox_count;
        private System.Windows.Forms.NumericUpDown label_value;
        private System.Windows.Forms.NumericUpDown textbox_value;
        private System.Windows.Forms.Button create;
    }
}

