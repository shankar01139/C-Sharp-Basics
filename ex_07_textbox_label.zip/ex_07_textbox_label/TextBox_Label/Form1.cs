﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TextBox_Label
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void create_Click(object sender, EventArgs e)
        {

            Form2 frm2 = new Form2();
            Form1 frm1 = new Form1();
            int pointX = 40;
            int pointY = 40;
            frm1.Hide();
            frm2.Show();
            for (int i = 0; i < textbox_value.Value; i++)
            {
                Label b = new Label();
                frm2.Controls.Add(b);
                b.Text = "Label";
                b.Location = new Point(pointX, pointY);
                pointY += 40;
            }
            
            for (int i = 0; i < textbox_value.Value; i++)
            {
                TextBox a = new TextBox();
                frm2.Controls.Add(a);
                a.Location = new Point(pointX, pointY);
                pointY += 40;
            }
           
        }
    }
}
